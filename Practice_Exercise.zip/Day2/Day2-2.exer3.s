.global _start

_start:
    MOV     R0, #0b10110100   // x = 0b10110100
    MOV     R1, #0            // count = 0

loop:
    CMP     R0, #0            // while (x != 0)
    BEQ     end

    AND     R2, R0, #1        // check LSB (x & 1)
    CMP     R2, #0
    BEQ     skip

    ADD     R1, R1, #1        // count++

skip:
    LSR     R0, R0, #1        // x = x >> 1
    B       loop

end:
    B       end               // infinite loop

