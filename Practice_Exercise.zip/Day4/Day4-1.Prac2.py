#!git clone https://github.com/GlobalSemiEdu/ExerciseUtil.git

from ExerciseUtil.waveform_logger import WaveformLogger
from pynq.lib.logictools.waveform import draw_wavedrom

class APBProtocol:
    CtrlSigs = ["PSEL", "PENABLE", "PWRITE", "PREADY", "PSLVERR"]
    DataSigs = ["PWDATA", "PRDATA", "PADDR"]
    ClkSig = "PCLK"
    AllSigs = [ClkSig] + CtrlSigs + DataSigs

    def __init__(self):
        self.signals = {}
        for sig in self.AllSigs:
            self.signals[sig] = 0

class APBMaster:
    def __init__(self, signals):
        self.signals = signals
        self.state = "IDLE"

    def write(self, addr, data):
        self.state = "SETUP"
        self.signals["PADDR"] = addr
        self.signals["PWRITE"] = 1
        self.signals["PWDATA"] = data

    def read(self, addr):
        self.state = "SETUP"
        self.signals["PADDR"] = addr
        self.signals["PWRITE"] = 0

    def tick(self):
        sig = self.signals
        sig["PSEL"] = 0
        sig["PENABLE"] = 0

        if self.state == "SETUP":
            sig["PSEL"] = 1
            sig["PENABLE"] = 0
            self.state = "ACCESS"
        elif self.state == "ACCESS":
            if sig["PREADY"] == 1:
                self.state = "IDLE"
            else:
                sig["PSEL"] = 1
                sig["PENABLE"] = 1


class APBSlave:
    def __init__(self, signals):
        self.signals = signals
        self.memory = {}

    def tick(self):
        sig = self.signals

        self.signals["PREADY"] = 0
        self.signals["PSLVERR"] = 0

        if sig["PSEL"] == 1:
            if sig["PENABLE"] == 0:
                self.addr = sig["PADDR"]
            else:
                self.signals["PREADY"] = 1
                if sig["PWRITE"] == 1:
                    self.memory[self.addr] = sig["PWDATA"]
                else:
                    if self.addr in self.memory:
                        sig["PRDATA"] = self.memory[self.addr]
                    else:
                        sig["PRDATA"] = 0xDEAD
                        self.signals["PSLVERR"] = 1




class APBModel:
    def __init__(self, logger):
        self.protocol = APBProtocol()
        self.logger = logger
        signals = self.protocol.signals
        self.logger.init_signals(self.protocol)
        self.logger.record(self.protocol.signals)
        self.master = APBMaster(signals)
        self.slave = APBSlave(signals)
        self.cycle = 0

    def read(self, addr):
        self.master.read(addr)

    def write(self, addr, data):
        self.master.write(addr, data)

    def step(self):
        self.master.tick()
        self.slave.tick()
        self.logger.record(self.protocol.signals)
        self.cycle += 1

    def is_done(self):
        return self.master.state == "IDLE"

logger = WaveformLogger()
apb = APBModel(logger)

apb.write(0x10, 0xAB)
while True:
    if apb.is_done():
        break
    apb.step()

apb.read(0x14)
while True:
    if apb.is_done():
        break
    apb.step()

apb.read(0x10)
while True:
    if apb.is_done():
        break
    apb.step()

draw_wavedrom(logger.to_json())
#print(logger.to_json())