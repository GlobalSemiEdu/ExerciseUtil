class AHBLiteProtocol:
    IDLE, BUSY, NONSEQ, SEQ = 0, 1, 2, 3                     # HTRANS encoding
    SINGLE, INCR, WRAP4, INCR4 = 0, 1, 2, 3               # HBURST encoding

    def htrans_name(self, value):
        names = ["IDLE", "BUSY", "NONSEQ", "SEQ"]
        return names[value]

    def hburst_name(self, value):
        names = ["SINGLE", "INCR", "WRAP4", "INCR4"]
        return names[value]

    def to_hex(self, value):
        if value is None:
            return "-"
        return hex(value)


class AHBTrace:
    # Signal order:
    HTRANS, HADDR, HWRITE, HSIZE, HBURST, HREADY, HRDATA = 0, 1, 2, 3, 4, 5, 6

    def __init__(self):
        self.rows = []

    def clear(self):
        self.rows = []

    def add(self, htrans, haddr, hwrite, hsize, hburst, hready, hrdata):
        self.rows.append([htrans, haddr, hwrite, hsize, hburst, hready, hrdata])

    def get_trace(self):
        return self.rows


class AHBReporter:
    def __init__(self, protocol, trace):
        self.p = protocol
        self.trace = trace

    def print_trace(self):
        rows = self.trace.get_trace()
        line_format = "{:<6} {:<8} {:<7} {:<7} {:<6} {:<8} {:<7} {:<8}"

        print(line_format.format("Cycle", "HTRANS", "HADDR", "HWRITE", "HSIZE", "HBURST", "HREADY", "HRDATA"))
        print(line_format.format("-----", "------", "-----", "------", "-----", "------", "------", "------"))

        for cycle in range(len(rows)):
            row = rows[cycle]
            print(line_format.format(
                cycle,
                self.p.htrans_name(row[AHBTrace.HTRANS]),
                self.p.to_hex(row[AHBTrace.HADDR]),
                row[AHBTrace.HWRITE],
                row[AHBTrace.HSIZE],
                self.p.hburst_name(row[AHBTrace.HBURST]),
                row[AHBTrace.HREADY],
                self.p.to_hex(row[AHBTrace.HRDATA])
            ))

class AHBGenerator:
    def __init__(self):
        self.protocol = AHBLiteProtocol()
        self.trace = AHBTrace()
        self.signal_generator = AHBSignalGenerator(self.protocol, self.trace)
        self.reporter = AHBReporter(self.protocol, self.trace)

    def generate_read_burst(self, start_addr, hburst, hsize=0, wait_at=None, wait_cycles=0):
        self.trace.clear()
        self.signal_generator.generate_read_burst(start_addr, hburst, hsize, wait_at, wait_cycles)

    def get_trace(self):
        return self.trace.get_trace()

    def print_trace(self):
        self.reporter.print_trace()

class AHBSignalGenerator:
    def __init__(self, protocol, trace):
        self.p = protocol
        self.trace = trace

    def read_memory(self, addr):
        return 0x10 + addr

    def next_incr_addr(self, addr, hsize):
        beat_size = 2 ** hsize
        return addr + beat_size

    def next_wrap4_addr(self, start_addr, addr, hsize):
        beat_size = 2 ** hsize
        burst_size = 4 * beat_size
        base = (start_addr // burst_size) * burst_size
        next_addr = addr + beat_size

        if next_addr >= base + burst_size:
            next_addr = base

        return next_addr

    def get_next_addr(self, start_addr, addr, hburst, hsize):
        if hburst == self.p.WRAP4:
            return self.next_wrap4_addr(start_addr, addr, hsize)
        return self.next_incr_addr(addr, hsize)

    def generate_read_burst(self, start_addr, hburst, hsize=0, wait_at=None, wait_cycles=0):
        hwrite = 0
        beat_count = 4
        addr = start_addr
        previous_addr = None

        for beat in range(beat_count):
            if beat == 0:
                htrans = self.p.NONSEQ
            else:
                htrans = self.p.SEQ

            if previous_addr is None:
                hrdata = 0xDEAD
            else:
                hrdata = self.read_memory(previous_addr)

            # Insert wait cycles for the selected beat
            if wait_at == beat:
                for _ in range(wait_cycles):
                    self.trace.add(htrans, addr, hwrite, hsize, hburst, 0, hrdata)

            # Transfer completes when HREADY is 1
            self.trace.add(htrans, addr, hwrite, hsize, hburst, 1, hrdata)

            previous_addr = addr
            addr = self.get_next_addr(start_addr, addr, hburst, hsize)

        # Extra cycle for the last read data
        self.trace.add(self.p.IDLE, 0x0, hwrite, hsize, hburst, 0, self.read_memory(previous_addr))