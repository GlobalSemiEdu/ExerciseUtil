#!git clone https://github.com/GlobalSemiEdu/ExerciseUtil.git

from ExerciseUtil.waveform_logger import WaveformLogger
from pynq.lib.logictools.waveform import draw_wavedrom

class AHBLiteProtocol:
    CtrlSigs = ["HWRITE", "HREADY"]
    DataSigs = ["HTRANS", "HADDR", "HRDATA", "HBURST"]
    ClkSig = "HCLK"
    AllSigs = [ClkSig] + CtrlSigs + DataSigs

    def __init__(self):
        self.signals = {}
        for sig in self.AllSigs:
            self.signals[sig] = 0
        self.signals["HREADY"] = 0
        self.signals["HWRITE"] = 0

class AHBMaster:
    def __init__(self, signals):
        self.signals = signals
        self.signals["HTRANS"] = 0  # IDLE

    def read_burst(self, start_addr, burst_type):
        self.signals["HBURST"] = burst_type
        self.addr = start_addr
        if burst_type == 3:
            self.read_count = 4
        self.signals["HADDR"] = self.addr
        self.signals["HTRANS"] = 2  # NONSEQ
        self.signals["HREADY"] = 1

    def tick(self):
        sig = self.signals

        if self.read_count > 1:
            self.addr += 1
            self.read_count -= 1
            sig["HREADY"] = 1
            sig["HADDR"] = self.addr
            sig["HTRANS"] = 3  # SEQ
        else:
            sig["HTRANS"] = 0  # IDLE
            sig["HREADY"] = 0


class AHBSlave:
    def __init__(self, signals):
        self.signals = signals
        self.memory = [i for i in range(0x10, 0x20)]

    def tick(self):
        sig = self.signals

        if sig["HREADY"] and sig["HTRANS"] in [2, 3]:  # 2:NONSEQ, 3:SEQ
            sig["HRDATA"] = self.memory[sig["HADDR"]]


class AHBLiteModel:
    def __init__(self, logger):
        self.protocol = AHBLiteProtocol()
        self.logger = logger
        self.signals = self.protocol.signals
        self.logger.init_signals(self.protocol)
        self.logger.record(self.protocol.signals)
        self.master = AHBMaster(self.signals)
        self.slave = AHBSlave(self.signals)
        self.cycle = 0

    def read_burst(self, addr, burst_type):
        self.master.read_burst(addr, burst_type)
        self.logger.record(self.protocol.signals)

    def step(self):
        self.master.tick()
        self.slave.tick()
        self.logger.record(self.protocol.signals)
        self.cycle += 1

    def is_done(self):
        return self.signals["HTRANS"] == 0

logger = WaveformLogger()
ahblite = AHBLiteModel(logger)

ahblite.read_burst(addr=0x2, burst_type=3)
while True:
    if ahblite.is_done():
        break
    ahblite.step()

draw_wavedrom(logger.to_json())
#print(logger.to_json())

