class APBTrace:
    # Signal order:
    PSEL, PENABLE, PWRITE, PADDR, PREADY, PRDATA, PSLVERR = 0, 1, 2, 3, 4, 5, 6

    def __init__(self, trace):
        self.trace = trace

    def length(self):
        return len(self.trace)

    def is_setup(self, cycle):
        return (self.trace[cycle][self.PSEL] == 1 and self.trace[cycle][self.PENABLE] == 0)

    def is_access(self, cycle):
        return (self.trace[cycle][self.PSEL] == 1 and self.trace[cycle][self.PENABLE] == 1)


class APBViolationList:
    def __init__(self):
        self.violations = []

    def clear(self):
        self.violations = []

    def add(self, cycle, message):
        self.violations.append("Cycle " + str(cycle) + ": " + message)

    def is_empty(self):
        return len(self.violations) == 0

class APBReporter:
    def __init__(self, violation_list):
        self.v = violation_list

    def print_report(self):
        if self.v.is_empty():
            print("PASS: No APB protocol violations found.")
        else:
            print("FAIL: APB protocol violations found.")

            for item in self.v.violations:
                print(item)

class APBChecker:
    def __init__(self, trace):
        self.trace = APBTrace(trace)
        self.violations = APBViolationList()
        self.rules = APBRuleChecker(self.trace, self.violations)
        self.reporter = APBReporter(self.violations)

    def check(self):
        self.violations.clear()
        self.rules.check_all()

    def print_report(self):
        self.reporter.print_report()

class APBRuleChecker:
    def __init__(self, apb_trace, violation_list):
        self.t = apb_trace
        self.v = violation_list
    def check_all(self):
        self.check_penable_without_psel()
        self.check_setup_phase()
        self.check_wait_state_stability()
        self.check_pslverr_timing()
        self.check_back_to_back_transfer()

    def check_penable_without_psel(self):
        for cycle in range(self.t.length()):
            row = self.t.trace[cycle]
            psel = row[APBTrace.PSEL]
            penable = row[APBTrace.PENABLE]
            if psel == 0 and penable == 1:
                self.v.add(cycle, "PENABLE is HIGH while PSEL is LOW.")
    def check_setup_phase(self):
        for cycle in range(self.t.length() - 1):
            if self.t.is_setup(cycle) and not self.t.is_access(cycle + 1):
                self.v.add(cycle + 1, "SETUP must be followed by ACCESS.")

    def check_wait_state_stability(self):
        for cycle in range(self.t.length() - 1):
            cur = self.t.trace[cycle]
            nxt = self.t.trace[cycle + 1]

            psel = cur[APBTrace.PSEL]
            penable = cur[APBTrace.PENABLE]
            pready = cur[APBTrace.PREADY]

            # ACCESS wait state:
            # PSEL = 1, PENABLE = 1, PREADY = 0
            if psel == 1 and penable == 1 and pready == 0:
                if cur[APBTrace.PADDR] != nxt[APBTrace.PADDR]:
                    self.v.add(cycle + 1, "PADDR changed during wait state.")

                if cur[APBTrace.PWRITE] != nxt[APBTrace.PWRITE]:
                    self.v.add(cycle + 1, "PWRITE changed during wait state.")

                if cur[APBTrace.PSEL] != nxt[APBTrace.PSEL]:
                    self.v.add(cycle + 1, "PSEL changed during wait state.")

                if cur[APBTrace.PENABLE] != nxt[APBTrace.PENABLE]:
                    self.v.add(cycle + 1, "PENABLE changed during wait state.")


    def check_back_to_back_transfer(self):
        for cycle in range(self.t.length() - 1):
            cur = self.t.trace[cycle]
            nxt = self.t.trace[cycle + 1]

            # Current cycle is a completed ACCESS cycle.
            current_access_done = (
                    cur[APBTrace.PSEL] == 1 and cur[APBTrace.PENABLE] == 1 and
                    cur[APBTrace.PREADY] == 1
            )

            # If the next cycle still selects a slave, it must be the SETUP phase of the next transfer.
            if current_access_done and nxt[APBTrace.PSEL] == 1:
                if nxt[APBTrace.PENABLE] == 1:
                    self.v.add(cycle + 1,  "PENABLE must go LOW for the next SETUP phase.")

    def check_pslverr_timing(self):
        for cycle in range(self.t.length()):
            row = self.t.trace[cycle]

            pslverr = row[APBTrace.PSLVERR]
            psel = row[APBTrace.PSEL]
            penable = row[APBTrace.PENABLE]
            pready = row[APBTrace.PREADY]

            # PSLVERR is valid only in the final ACCESS cycle.
            if pslverr == 1:
                if not (psel == 1 and penable == 1 and pready == 1):
                    self.v.add(cycle, "PSLVERR is HIGH outside final ACCESS cycle.")
