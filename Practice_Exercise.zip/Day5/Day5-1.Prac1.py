from waveform_logger import WaveformLogger
from pynq.lib.logictools.waveform import draw_wavedrom
import random

class AXILiteProtocol:
    def __init__(self):
        self.signals = {}
        self._init_signals()

    def get_control_signals(self):
        return ["AWVALID", "AWREADY", "WVALID", "WREADY", "BVALID", "BREADY"]

    def get_data_signals(self):
        return ["AWADDR", "WDATA", "BRESP"]

    def get_clock_signal(self):
        return "ACLK"

    def _init_signals(self):
        self.signals[self.get_clock_signal()] = 0
        for sig in self.get_control_signals():
            self.signals[sig] = 0
        for sig in self.get_data_signals():
            self.signals[sig] = 0

    def get_data_validity(self):
        return {
            "AWADDR": lambda s: s["AWVALID"] == 1,
            "WDATA":  lambda s: s["WVALID"] == 1,
            "BRESP":  lambda s: s["BVALID"] == 1,
            "ARADDR": lambda s: s["ARVALID"] == 1,
            "RDATA":  lambda s: s["RVALID"] == 1,
            "RRESP":  lambda s: s["RVALID"] == 1,
        }


class AXILiteMaster:
    def __init__(self, signals):
        self.signals = signals
        self.state = "IDLE"

        self.addr = 0
        self.wdata = 0
        self.bresp = 0

    def start_write(self, addr, data):
        self.txn_kind = "write"
        self.addr = addr
        self.wdata = data
        self.state = "AW_ACCEPT_WAIT"

    def tick(self):
        s = self.signals

        s["AWVALID"] = 0
        s["WVALID"]  = 0
        s["BREADY"]  = 0

        if self.state == "IDLE":
            return

        if self.state == "AW_ACCEPT_WAIT":
            s["AWADDR"] = self.addr
            s["AWVALID"] = 1
            if s["AWREADY"] == 1:
                self.state = "W_ACCEPT_WAIT"
            elif self.state == "W_ACCEPT_WAIT":
                s["WDATA"] = self.wdata
                s["WVALID"] = 1
                if s["WREADY"] == 1:
                    self.state = "B_WAIT"
            elif self.state == "B_WAIT":
                s["BREADY"] = 1
                if s["BVALID"] == 1:
                    self.bresp = s["BRESP"]
                    self.state = "IDLE"

    def is_idle(self):
        return self.state == "IDLE"

class AXILiteSlave:
    OKAY = 0b00

    def __init__(self, signals):
        self.signals = signals
        self.memory = {}

        self._aw_seen = False
        self._w_seen  = False
        self._aw_addr = 0
        self._w_data  = 0
        self._b_countdown = None

        self._aw_wait = 0
        self._w_wait  = 0

    def tick(self, wait_states=0, randomize_ready=False):
        s = self.signals

        s["AWREADY"] = 0
        s["WREADY"]  = 0

        if "BVALID" not in s:
            s["BVALID"] = 0
        if s["BVALID"] == 1 and s["BREADY"] == 1:
            s["BVALID"] = 0

        if s["AWVALID"] == 1 and not self._aw_seen and self._aw_wait == 0:
            self._aw_wait = wait_states
        if s["WVALID"] == 1 and not self._w_seen and self._w_wait == 0:
            self._w_wait = wait_states

        if s["AWVALID"] == 1 and not self._aw_seen:
            if randomize_ready and random.choice([0, 1]) == 0:
                pass
            else:
                if self._aw_wait > 0:
                    self._aw_wait -= 1
                else:
                    s["AWREADY"] = 1
                    if s["AWREADY"] == 1:  # handshake
                        self._aw_seen = True
                        self._aw_addr = s["AWADDR"]

        if s["WVALID"] == 1 and not self._w_seen:
            if randomize_ready and random.choice([0, 1]) == 0:
                pass
            else:
                if self._w_wait > 0:
                    self._w_wait -= 1
                else:
                    s["WREADY"] = 1
                    if s["WREADY"] == 1:  # handshake
                        self._w_seen = True
                        self._w_data = s["WDATA"]

        # -----------------------
        # Schedule / produce B response after AW+W accepted
        # -----------------------
        if self._aw_seen and self._w_seen and self._b_countdown is None and s["BVALID"] == 0:
            self._b_countdown = wait_states

        if self._b_countdown is not None and s["BVALID"] == 0:
            if self._b_countdown > 0:
                self._b_countdown -= 1
            else:
                # commit write + assert response
                self.memory[self._aw_addr] = self._w_data
                s["BRESP"] = self.OKAY
                s["BVALID"] = 1
                # clear write acceptance state
                self._aw_seen = False
                self._w_seen = False
                self._b_countdown = None
                self._aw_wait = 0
                self._w_wait = 0

class AXILiteSimulator:
    def __init__(self):
        self.protocol = AXILiteProtocol()
        self.signals = self.protocol.signals

        self.master = AXILiteMaster(self.signals)
        self.slave = AXILiteSlave(self.signals)

        self.logger = WaveformLogger(self.protocol)
        self.cycle = 0
        self.current_wait_states = 0
        self.randomize_ready = False

    def step(self):
        self.signals["ACLK"] ^= 1

        self.master.tick()
        self.slave.tick(wait_states=self.current_wait_states, randomize_ready=self.randomize_ready)

        self.logger.record(self.signals)
        self.cycle += 1

    def run_transaction(self, transaction_type, addr, data=None, wait_states=0, add_idle=False, randomize_ready=False):
        self.current_wait_states = wait_states
        self.randomize_ready = randomize_ready

        if transaction_type == "write":
            if data is None:
                raise ValueError("write requires data")
            self.master.start_write(addr, data)

        while not self.master.is_idle():
            self.step()

        if add_idle:
            self.step()

    def get_waveform(self):
        return self.logger.to_wavedrom()

sim = AXILiteSimulator()
sim.run_transaction("write", addr=0x10, data=0xAB, wait_states=0, add_idle=True)
draw_wavedrom(sim.get_waveform())

sim1 = AXILiteSimulator()
sim1.run_transaction("write", addr=0x30, data=0xEE, wait_states=1, add_idle=True, randomize_ready=True)
draw_wavedrom(sim1.get_waveform())
