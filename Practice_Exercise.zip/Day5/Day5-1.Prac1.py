!git clone https://github.com/GlobalSemiEdu/ExerciseUtil.git

from ExerciseUtil.waveform_logger import WaveformLogger
from pynq.lib.logictools.waveform import draw_wavedrom


import random

class AXILiteProtocol:
    CtrlSigs = ["AWVALID", "AWREADY", "WVALID", "WREADY", "BVALID", "BREADY"]
    DataSigs = ["AWADDR", "WDATA", "BRESP"]
    ClkSig = "ACLK"
    AllSigs = [ClkSig] + CtrlSigs + DataSigs

    def __init__(self):
        self.signals = {sig: 0 for sig in self.AllSigs}

class AXILiteMasterFSM:
    def __init__(self):
        self.state = "IDLE"
        self.next_addr = None
        self.next_data = None

    def start_write(self, addr, data):
        self.next_addr = addr
        self.next_data = data
        self.state = "AW_ACCEPT_WAIT"

    def update(self, awready, wready, bvalid):
        if self.state == "AW_ACCEPT_WAIT" and awready:
            self.state = "W_ACCEPT_WAIT"
        elif self.state == "W_ACCEPT_WAIT" and wready:
            self.state = "RESPOND"
        elif self.state == "RESPOND" and bvalid:
            self.state = "DONE"

class AXILiteMaster:
    def __init__(self, signals):
        self.signals = signals
        self.fsm = AXILiteMasterFSM()
        self.signals["AWADDR"] = 0xF
        self.signals["WDATA"] = 0xF
        self.signals["BRESP"] = 0x3

    def write(self, addr, data):
        self.fsm.start_write(addr, data)

    def tick(self):
        sig = self.signals
        state = self.fsm.state

        sig["AWVALID"] = 0
        sig["WVALID"] = 0
        sig["BREADY"] = 0

        self.fsm.update(
            awready=sig["AWREADY"],
            wready=sig["WREADY"],
            bvalid=sig["BVALID"]
        )

        state = self.fsm.state

        if state == "AW_ACCEPT_WAIT":
            sig["AWADDR"] = self.fsm.next_addr
            sig["AWVALID"] = 1
        elif state == "W_ACCEPT_WAIT":
            sig["WDATA"] = self.fsm.next_data
            sig["WVALID"] = 1
        elif state == "RESPOND":
            sig["BREADY"] = 1

class AXILiteSlave:
    def __init__(self, signals):
        self.signals = signals
        self.pending_write = False

    def tick(self):
        sig = self.signals

        sig["AWREADY"] = random.choice([0, 1])
        sig["WREADY"] = random.choice([0, 1])

        sig["BRESP"] = 0   # OKAY
        sig["BVALID"] = 1

class AXILiteModel:
    def __init__(self, logger):
        self.protocol = AXILiteProtocol()
        self.logger = logger
        signals = self.protocol.signals
        self.logger.init_signals(self.protocol)
        self.master = AXILiteMaster(signals)
        self.slave = AXILiteSlave(signals)
        self.cycle = 0

    def write(self, addr, data):
        self.logger.record(self.protocol.signals)
        self.master.write(addr, data)

    def step(self):
        self.master.tick()
        self.slave.tick()
        self.logger.record(self.protocol.signals)
        self.cycle += 1

    def is_done(self):
        return self.master.fsm.state == "DONE"


logger = WaveformLogger()
axi = AXILiteModel(logger)

axi.write(0x10, 0x1234)

while True:
    axi.step()
    if axi.is_done():
        break

draw_wavedrom(logger.to_json())